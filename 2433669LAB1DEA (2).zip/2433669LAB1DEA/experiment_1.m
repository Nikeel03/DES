% Please import the generatesubkeyQ1.m file which is the designed function
% for Outcome 1.
% Run this code to test the implementation of the function.
permkey = '01101111001100111100011001011111000011001110101001110101';
i = 16; % 16 rounds
subkeys = generatesubkeyQ1(permkey,i);
disp(subkeys)