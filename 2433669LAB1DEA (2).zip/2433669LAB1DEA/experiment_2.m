clear all
clc
%%
% Please import the generatesubkey.m file which is the designed function
% Run this code to test the implementation of the function
% Converting Sixty-four bit hexadecimal to Sixty-four bit binary
hkey = '1F1F1F1F0E0E0E0E';
    key1 = '';
    for i=1:length(hkey)
        key1 = [key1,dec2bin(hex2dec(hkey(i)),4)];
    end
hkey2 = '1FFE1FFE0EFE0EFE';
    key2 = '';
    for i=1:length(hkey2)
        key2 = [key2,dec2bin(hex2dec(hkey2(i)),4)];
    end
hkey3 = '1FFEFE1F0EFEFE0E';
    key3 = '';
    for i=1:length(hkey3)
        key3 = [key3,dec2bin(hex2dec(hkey3(i)),4)];
    end

    % Permutation table to achieve 56-bit Key input
    perm = [57 49 41 33 25 17 9 1 58 50 42 34 26 18 10 2 59 51 43 35 27 19 11 3 60 52 44 36 63 55 47 39 31 23 15 7 62 54 46 38 30 22 14 6 61 53 45 37 29 21 13 5 28 20 12 4];
    permkey1 = key1(perm);
    permkey2 = key2(perm);
    permkey3 = key3(perm);

    % Calling the Subkey generation function which is now a cell array of
    % 16 rows and 48 columns
    subkeys1 = generatesubkey(permkey1);
    subkeys2 = generatesubkey(permkey2);
    subkeys3 = generatesubkey(permkey3);

    % Rounds
    for i=1:16
        sub_key1 = num2str(subkeys1{i}); % Extracting the specific subkey per round
        disp(sub_key1) % 1 unique subkey depiction
    end
    disp('------------------------------------------------')
    for i=1:16
        sub_key2 = num2str(subkeys2{i}); % Extracting the specific subkey per round
        disp(sub_key2) % 2 unique subkeys depiction
    end
    disp('------------------------------------------------')
    for i=1:16
        sub_key3 = num2str(subkeys3{i}); % Extracting the specific subkey per round
        disp(sub_key3) % 4 unique subkeys depiction
    end