clear all
clc
%%
% Combining all plaintexts
% Plaintext of any string length
plaintext = '24336692346951AB24336692346951AB24336692346951AB24336692346951AB24336692346951AB';

% Computation of frequency of each character
characters = unique(plaintext);
frequency = zeros(size(characters));
for i = 1:length(characters)
    frequency(i) = sum(plaintext == characters(i));
end

% Ciphertext of any string length
ciphertext = '0B256E7A2560D4547F7394FF8F91E14C40ADD3F30D2F7EF38F374B375B98AA6E0DE2C98F71C90660';

% Computation of frequency of each character
characters2 = unique(ciphertext);
frequency2 = zeros(size(characters2));
for i = 1:length(characters2)
    frequency2(i) = sum(ciphertext == characters2(i));
end

% Ciphertext of any string length
key = '0123456789ABCDEFFEDCBA9876543210AABB09182736CCDD3FA40E8A984D48152736CCDD5F3A829C';

% Computation of frequency of each character
characters3 = unique(key);
frequency3 = zeros(size(characters3));
for i = 1:length(characters2)
    frequency3(i) = sum(key == characters3(i));
end

figure;
grid on;
plot(1:numel(characters),frequency,'-o','LineWidth',2);
title('Frequency Analysis of Plaintext');
xlabel('Character Index');
ylabel('Frequency');

figure;
grid on;
plot(1:numel(characters2),frequency2,'-o','LineWidth',2);
title('Frequency Analysis of Ciphertext');
xlabel('Character Index');
ylabel('Frequency');

figure;
grid on;
plot(1:numel(characters3),frequency3,'-o','LineWidth',2);
title('Frequency Analysis of Key');
xlabel('Character Index');
ylabel('Frequency');
%%
clear all
clc
%%
% Combining all plaintexts
% Plaintext of any string length
plaintext = '24336692346951AB24336692346951AB24336692346951AB';

% Computation of frequency of each character
characters = unique(plaintext);
frequency = zeros(size(characters));
for i = 1:length(characters)
    frequency(i) = sum(plaintext == characters(i));
end

% Ciphertext of any string length
ciphertext = 'CCDCEFA8CA6AFB7056FF468B220D4037E80181533BBF668D';

% Computation of frequency of each character
characters2 = unique(ciphertext);
frequency2 = zeros(size(characters2));
for i = 1:length(characters2)
    frequency2(i) = sum(ciphertext == characters2(i));
end

% Ciphertext of any string length
key = '1F1F1F1F0E0E0E0E1FFE1FFE0EFE0EFE1FFEFE1F0EFEFE0E';
% Computation of frequency of each character
characters3 = unique(key);
frequency3 = zeros(size(characters3));
for i = 1:length(characters3)
    frequency3(i) = sum(key == characters3(i));
end

figure;
grid on;
plot(1:numel(characters),frequency,'-o','LineWidth',2);
title('Frequency Analysis of Plaintext');
xlabel('Character Index');
ylabel('Frequency');

figure;
grid on;
plot(1:numel(characters2),frequency2,'-o','LineWidth',2);
title('Frequency Analysis of Ciphertext With Weak Keys');
xlabel('Character Index');
ylabel('Frequency');

figure;
grid on;
plot(1:numel(characters3),frequency3,'-o','LineWidth',2);
title('Frequency Analysis of Weak Keys');
xlabel('Character Index');
ylabel('Frequency');