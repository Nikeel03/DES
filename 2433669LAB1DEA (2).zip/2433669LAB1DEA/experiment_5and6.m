clear all
clc 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                                                                     
% Please import the DEA.m and the generatesubkey.m functions
% The following key and ciphertext were obtained from a reputable website:
% https://page.math.tu-berlin.de/~kant/teaching/hess/krypto-ws2006/des.htm
% The plaintext was compared and matched that of the online source
cyphertext = '85E813540F0AB405';                                                           
hkey = '133457799BBCDFF1'; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Converting Sixty-four bit hexadecimal to Sixty-four bit binary
    key = '';
    for i=1:length(hkey)
        key = [key,dec2bin(hex2dec(hkey(i)),4)];
    end
    sixty4bit = '';
    for i=1:length(cyphertext)
        sixty4bit = [sixty4bit,dec2bin(hex2dec(cyphertext(i)),4)];
    end

    % Both undergo Permuations
    perm = [57 49 41 33 25 17 9 1 58 50 42 34 26 18 10 2 59 51 43 35 27 19 11 3 60 52 44 36 63 55 47 39 31 23 15 7 62 54 46 38 30 22 14 6 61 53 45 37 29 21 13 5 28 20 12 4];
    permkey = key(perm);

    initialperm = [58 50 42 34 26 18 10 2 60 52 44 36 28 20 12 4 62 54 46 38 30 22 14 6 64 56 48 40 32 24 16 8 57 49 41 33 25 17 9 1 59 51 43 35 27 19 11 3 61 53 45 37 29 21 13 5 63 55 47 39 31 23 15 7];
    sixty4bits = sixty4bit(initialperm);
    
    % Calling the Subkey generation function which is now a cell array of
    % 16 rows and 48 columns
    subkeys = generatesubkey(permkey);

    % Rounds
    for i=1:16
        sub_key = num2str(subkeys{17-i}); % Extracting the specific subkey per round
        [Lbit6,nospaceRbit] = DEA(sixty4bits,i,sub_key); 
        sixty4bits = [Lbit6 nospaceRbit]; 
    end
    
    % Final Permutation table
    perm4 = [40 8 48 16 56 24 64 32 39 7 47 15 55 23 63 31 38 6 46 14 54 22 62 30 37 5 45 13 53 21 61 29 36 4 44 12 52 20 60 28 35 3 43 11 51 19 59 27 34 2 42 10 50 18 58 26 33 1 41 9 49 17 57 25];
    plaintextbinary = sixty4bits(perm4);

    % Converting binary ciphertext to hexadecimal ciphertext
    plaintext = '';
    for i=1:4:length(plaintextbinary)
        nibbles = plaintextbinary(i:i+3); % Allows to convert in 4 bits at a time
        hex = dec2hex(bin2dec(nibbles));
        plaintext = [plaintext,hex];
    end

    disp('The plaintext: ')
    disp(plaintext) 