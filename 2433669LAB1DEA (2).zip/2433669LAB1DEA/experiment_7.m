clear all
clc                                 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Please import the DEA.m and the generatesubkey.m functions
hkey = '0000000000000000'; 
plaintext1 = '0123456789ABCDEF';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Converting Sixty-four bit hexadecimal to Sixty-four bit binary
    key = '';
    for i=1:length(hkey)
        key = [key,dec2bin(hex2dec(hkey(i)),4)];
    end
    sixty4bit1 = '';
    for i=1:length(plaintext1)
        sixty4bit1 = [sixty4bit1,dec2bin(hex2dec(plaintext1(i)),4)];
    end

    % Both undergo Permuations
    perm = [57 49 41 33 25 17 9 1 58 50 42 34 26 18 10 2 59 51 43 35 27 19 11 3 60 52 44 36 63 55 47 39 31 23 15 7 62 54 46 38 30 22 14 6 61 53 45 37 29 21 13 5 28 20 12 4];
    permkey = key(perm);

    initialperm = [58 50 42 34 26 18 10 2 60 52 44 36 28 20 12 4 62 54 46 38 30 22 14 6 64 56 48 40 32 24 16 8 57 49 41 33 25 17 9 1 59 51 43 35 27 19 11 3 61 53 45 37 29 21 13 5 63 55 47 39 31 23 15 7];
    sixty4bits1 = sixty4bit1(initialperm);

    % Calling the Subkey generation function which is now a cell array of
    % 16 rows and 48 columns
    subkeys = generatesubkey(permkey);

    % Rounds
    for i=1:16
        sub_key = num2str(subkeys{i}); % Extracting the specific subkey per round
        [Lbit6,nospaceRbit] = DEA(sixty4bits1,i,sub_key); % Two 32-bit blocks produced by function
        sixty4bits1 = [Lbit6 nospaceRbit]; 
    end

    % Final Permutation table
    perm4 = [40 8 48 16 56 24 64 32 39 7 47 15 55 23 63 31 38 6 46 14 54 22 62 30 37 5 45 13 53 21 61 29 36 4 44 12 52 20 60 28 35 3 43 11 51 19 59 27 34 2 42 10 50 18 58 26 33 1 41 9 49 17 57 25];
    ciphertextbinary = sixty4bits1(perm4);

    % Converting binary ciphertext to hexadecimal ciphertext
    ciphertext = '';
    for i=1:4:length(ciphertextbinary)
        nibbles = ciphertextbinary(i:i+3); % Allows to convert in 4 bits at a time
        hex = dec2hex(bin2dec(nibbles));
        ciphertext = [ciphertext,hex];
    end

    disp('The ciphertext for "0000000000000000": ')
    disp(ciphertext) 
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
avalanche = '1000000000000000'; % A single bit change
plaintext1 = '0123456789ABCDEF';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Converting Sixty-four bit hexadecimal to Sixty-four bit binary
    key = '';
    for i=1:length(avalanche)
        key = [key,dec2bin(hex2dec(avalanche(i)),4)];
    end
    sixty4bit1 = '';
    for i=1:length(plaintext1)
        sixty4bit1 = [sixty4bit1,dec2bin(hex2dec(plaintext1(i)),4)];
    end

    % Both undergo Permuations
    perm = [57 49 41 33 25 17 9 1 58 50 42 34 26 18 10 2 59 51 43 35 27 19 11 3 60 52 44 36 63 55 47 39 31 23 15 7 62 54 46 38 30 22 14 6 61 53 45 37 29 21 13 5 28 20 12 4];
    permkey = key(perm);

    initialperm = [58 50 42 34 26 18 10 2 60 52 44 36 28 20 12 4 62 54 46 38 30 22 14 6 64 56 48 40 32 24 16 8 57 49 41 33 25 17 9 1 59 51 43 35 27 19 11 3 61 53 45 37 29 21 13 5 63 55 47 39 31 23 15 7];
    sixty4bits1 = sixty4bit1(initialperm);

    % Calling the Subkey generation function which is now a cell array of
    % 16 rows and 48 columns
    subkeys = generatesubkey(permkey);

    % Rounds
    for i=1:16
        sub_key = num2str(subkeys{i}); % Extracting the specific subkey per round
        [Lbit6,nospaceRbit] = DEA(sixty4bits1,i,sub_key); % Two 32-bit blocks produced by function
        sixty4bits1 = [Lbit6 nospaceRbit]; 
    end

    % Final Permutation table
    perm4 = [40 8 48 16 56 24 64 32 39 7 47 15 55 23 63 31 38 6 46 14 54 22 62 30 37 5 45 13 53 21 61 29 36 4 44 12 52 20 60 28 35 3 43 11 51 19 59 27 34 2 42 10 50 18 58 26 33 1 41 9 49 17 57 25];
    ciphertextbinary = sixty4bits1(perm4);

    % Converting binary ciphertext to hexadecimal ciphertext
    ciphertext = '';
    for i=1:4:length(ciphertextbinary)
        nibbles = ciphertextbinary(i:i+3); % Allows to convert in 4 bits at a time
        hex = dec2hex(bin2dec(nibbles));
        ciphertext = [ciphertext,hex];
    end

    disp('The ciphertext for a singular bit change in the key being "1000000000000000": ')
    disp(ciphertext) 